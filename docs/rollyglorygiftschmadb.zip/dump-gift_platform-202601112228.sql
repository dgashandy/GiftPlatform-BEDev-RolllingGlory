--
-- PostgreSQL database dump
--

-- Dumped from database version 15.15
-- Dumped by pg_dump version 17.0

-- Started on 2026-01-11 22:28:35

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 214 (class 1259 OID 16389)
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- TOC entry 215 (class 1259 OID 16399)
-- Name: gifts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gifts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    category_id uuid,
    points_required integer NOT NULL,
    stock integer DEFAULT 0 NOT NULL,
    image_url character varying(500),
    badge_type character varying(20),
    avg_rating numeric(3,2) DEFAULT '0'::numeric,
    total_reviews integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.gifts OWNER TO postgres;

--
-- TOC entry 216 (class 1259 OID 16413)
-- Name: migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    applied_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.migrations OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 16419)
-- Name: point_balance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.point_balance (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    transaction_type character varying(50) NOT NULL,
    amount integer NOT NULL,
    balance_after integer NOT NULL,
    description character varying(255),
    reference_id uuid,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.point_balance OWNER TO postgres;

--
-- TOC entry 218 (class 1259 OID 16426)
-- Name: ratings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ratings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    gift_id uuid NOT NULL,
    redemption_id uuid NOT NULL,
    stars integer NOT NULL,
    review text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ratings OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 16435)
-- Name: redemptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.redemptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    gift_id uuid NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    points_spent integer NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.redemptions OWNER TO postgres;

--
-- TOC entry 220 (class 1259 OID 16444)
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(50) NOT NULL,
    permissions json DEFAULT '[]'::json,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 16456)
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255),
    name character varying(255) NOT NULL,
    phone character varying(20),
    avatar_url character varying(500),
    role_id uuid NOT NULL,
    is_verified boolean DEFAULT false NOT NULL,
    google_id character varying(255),
    otp_code character varying(6),
    otp_expires_at timestamp without time zone,
    refresh_token character varying(500),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- TOC entry 3487 (class 0 OID 16389)
-- Dependencies: 214
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, name, slug, is_active, created_at) FROM stdin;
101024b5-723b-4438-b50f-d37c898e42b1	Electronics	electronics	t	2026-01-11 12:08:40.067182
50a68311-e643-4c66-98c2-076906118efc	Fashion	fashion	t	2026-01-11 12:08:40.067182
4e0c6956-81c4-4726-bd82-fc2c5f5c47ef	Home & Living	home-living	t	2026-01-11 12:08:40.067182
e0412913-d3be-4b40-a8c9-d8858f70418e	Sports & Outdoors	sports-outdoors	t	2026-01-11 12:08:40.067182
14e8c752-7775-454d-af59-42cc2645eb55	Beauty & Health	beauty-health	t	2026-01-11 12:08:40.067182
7399e3e8-cd52-42f0-9086-99f33944ff3e	Vouchers	vouchers	t	2026-01-11 12:08:40.067182
\.


--
-- TOC entry 3488 (class 0 OID 16399)
-- Dependencies: 215
-- Data for Name: gifts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gifts (id, name, description, category_id, points_required, stock, image_url, badge_type, avg_rating, total_reviews, is_active, created_at, updated_at) FROM stdin;
26cdf969-d5ca-43d2-8e80-649afc2bceca	Samsung Galaxy S9 - Midnight Black 4/64 GB	Experience the revolutionary camera that adapts like the human eye. It automatically switches between various lighting conditions, making stunning photos in Super Low Light, and icons bright daylight.	101024b5-723b-4438-b50f-d37c898e42b1	750	5	/images/samsung-s9.jpg	bestseller	4.50	160	t	2026-01-11 12:08:40.07037	2026-01-11 12:08:40.07037
fbdb3497-f9bc-4346-85fc-40c240e15b67	Apple AirPods Pro 2nd Gen	Active Noise Cancellation and Transparency mode. Personalized Spatial Audio with dynamic head tracking.	101024b5-723b-4438-b50f-d37c898e42b1	650	10	/images/airpods-pro.jpg	hotitem	4.80	250	t	2026-01-11 12:08:40.07037	2026-01-11 12:08:40.07037
60876c0f-331a-4fe7-8247-1a708e2e4a30	Nike Air Max 270	The Nike Air Max 270 delivers visible cushioning under every step. Updated for modern comfort, it features Nike's biggest heel Air unit yet.	50a68311-e643-4c66-98c2-076906118efc	450	15	/images/nike-airmax.jpg	newitem	4.20	85	t	2026-01-11 12:08:40.07037	2026-01-11 12:08:40.07037
60401028-2e5b-4c4e-94c8-7c167ec58037	Sony WH-1000XM5 Headphones	Industry-leading noise cancellation. Crystal clear hands-free calling with 4 beamforming microphones.	101024b5-723b-4438-b50f-d37c898e42b1	800	0	/images/sony-headphones.jpg	bestseller	4.70	180	t	2026-01-11 12:08:40.07037	2026-01-11 12:08:40.07037
949b77cd-fe16-4bd2-bf8d-0e87300a30d1	Adidas Ultraboost 22	Incredibly responsive cushioning and a Linear Energy Push system for a smooth, well-cushioned ride.	50a68311-e643-4c66-98c2-076906118efc	550	20	\N	newitem	4.30	95	t	2026-01-11 12:08:40.07037	2026-01-11 12:08:40.07037
573057cf-3a8e-4cb5-b48e-de1b04e4a927	Starbucks Gift Card Rp 500.000	Enjoy your favorite Starbucks drinks and food with this prepaid gift card.	7399e3e8-cd52-42f0-9086-99f33944ff3e	300	98	/images/starbucks-voucher.jpg	\N	2.00	2	t	2026-01-11 12:08:40.07037	2026-01-11 12:25:14.762
6aa92af2-b1f2-4ddf-905a-8c97ccbb3f3c	Wireless Charging Pad	Fast wireless charging for all Qi-compatible devices. Sleek and compact design.	101024b5-723b-4438-b50f-d37c898e42b1	350	49	\N	\N	4.05	43	t	2026-01-11 12:08:40.07037	2026-01-11 12:26:34.687
\.


--
-- TOC entry 3489 (class 0 OID 16413)
-- Dependencies: 216
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migrations (id, name, applied_at) FROM stdin;
\.


--
-- TOC entry 3490 (class 0 OID 16419)
-- Dependencies: 217
-- Data for Name: point_balance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.point_balance (id, user_id, transaction_type, amount, balance_after, description, reference_id, created_at) FROM stdin;
05667167-61ed-4fd7-9809-46c87161db7b	fe11cf2f-89e5-42a8-a6b9-096c24219e6d	credit	1000	1000	Welcome bonus - New user registration	\N	2026-01-11 12:11:21.523269
3bb4eaf7-9d60-4dee-83dc-55d1967c8cc0	fe11cf2f-89e5-42a8-a6b9-096c24219e6d	debit	-350	650	Redeemed 1x Wireless Charging Pad	e395f4c7-9ad2-4614-a682-6884d119d5fa	2026-01-11 12:26:21.888412
d9b59f9f-8cb7-4f98-815f-534c6e4c922e	a4529f5b-db16-4dae-ba43-a96ee601f185	credit	1000	1000	Welcome bonus - New user registration	\N	2026-01-11 15:17:24.104351
\.


--
-- TOC entry 3491 (class 0 OID 16426)
-- Dependencies: 218
-- Data for Name: ratings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ratings (id, user_id, gift_id, redemption_id, stars, review, created_at) FROM stdin;
eb9bccd2-3ee1-45e5-a399-f57726c10510	fe11cf2f-89e5-42a8-a6b9-096c24219e6d	573057cf-3a8e-4cb5-b48e-de1b04e4a927	c600a31f-ec1b-43b5-a9fc-d4514a05fdd3	1	rate 1x	2026-01-11 12:24:54.592647
7ad50c0c-0348-4ff2-8211-af1db8bb4d4e	fe11cf2f-89e5-42a8-a6b9-096c24219e6d	573057cf-3a8e-4cb5-b48e-de1b04e4a927	4a5f059e-c8fc-47e6-b27d-2df8cc03d676	3	rate 2x	2026-01-11 12:25:14.75515
b30fb8ac-7638-4996-afa0-02b6b4896542	fe11cf2f-89e5-42a8-a6b9-096c24219e6d	6aa92af2-b1f2-4ddf-905a-8c97ccbb3f3c	e395f4c7-9ad2-4614-a682-6884d119d5fa	2	rate ke 43\n	2026-01-11 12:26:34.681387
\.


--
-- TOC entry 3492 (class 0 OID 16435)
-- Dependencies: 219
-- Data for Name: redemptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.redemptions (id, user_id, gift_id, quantity, points_spent, status, created_at) FROM stdin;
4a5f059e-c8fc-47e6-b27d-2df8cc03d676	fe11cf2f-89e5-42a8-a6b9-096c24219e6d	573057cf-3a8e-4cb5-b48e-de1b04e4a927	1	300	completed	2026-01-11 12:24:25.130732
c600a31f-ec1b-43b5-a9fc-d4514a05fdd3	fe11cf2f-89e5-42a8-a6b9-096c24219e6d	573057cf-3a8e-4cb5-b48e-de1b04e4a927	1	300	completed	2026-01-11 12:24:39.055537
e395f4c7-9ad2-4614-a682-6884d119d5fa	fe11cf2f-89e5-42a8-a6b9-096c24219e6d	6aa92af2-b1f2-4ddf-905a-8c97ccbb3f3c	1	350	completed	2026-01-11 12:26:21.883227
\.


--
-- TOC entry 3493 (class 0 OID 16444)
-- Dependencies: 220
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, name, permissions, created_at) FROM stdin;
e2ed159c-9469-468a-96b7-fc4e0604b07c	admin	["*"]	2026-01-11 12:08:39.955295
8dde5787-9688-45ca-92eb-86b5b3919fb2	support	["gifts:read","gifts:create","gifts:update","users:read"]	2026-01-11 12:08:39.959712
ab42e228-882b-4f29-b9ab-1d9794decedc	user	["gifts:read","gifts:redeem","ratings:create","profile:update"]	2026-01-11 12:08:39.961433
\.


--
-- TOC entry 3494 (class 0 OID 16456)
-- Dependencies: 221
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, password_hash, name, phone, avatar_url, role_id, is_verified, google_id, otp_code, otp_expires_at, refresh_token, created_at, updated_at) FROM stdin;
0decf254-3a4d-4c01-a50a-5c608d95b7b0	support@giftplatform.com	$2b$10$TFmqqr5cuPxOz4fwCXMZs.BOM/rEd20FPixganT7BuZZ0dItLauXG	Support Staff	\N	\N	8dde5787-9688-45ca-92eb-86b5b3919fb2	t	\N	\N	\N	\N	2026-01-11 12:08:40.064944	2026-01-11 12:08:40.064944
fe11cf2f-89e5-42a8-a6b9-096c24219e6d	dgashandy@gmail.com	\N	Daffa Gashandy	\N	https://lh3.googleusercontent.com/a/ACg8ocKsVkL_6Wc2aMa9SqBxhftYlehstGBTkpJ3q5eJaQT_FaYN5Vqj=s96-c	ab42e228-882b-4f29-b9ab-1d9794decedc	t	106607303192445131485	\N	\N	\N	2026-01-11 12:11:21.518956	2026-01-11 12:11:21.518956
23b6b619-c2d1-4e38-a3c4-652f79e16b85	admin@giftplatform.com	$2b$10$URmsygZidzGpfxdjijW8WOWUzkAPptAxwHb8wo7x2JEUHCoc75CcS	System Admin	\N	\N	e2ed159c-9469-468a-96b7-fc4e0604b07c	t	\N	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyM2I2YjYxOS1jMmQxLTRlMzgtYTNjNC02NTJmNzllMTZiODUiLCJlbWFpbCI6ImFkbWluQGdpZnRwbGF0Zm9ybS5jb20iLCJyb2xlSWQiOiJlMmVkMTU5Yy05NDY5LTQ2OGEtOTZiNy1mYzRlMDYwNGIwN2MiLCJyb2xlTmFtZSI6ImFkbWluIiwiaWF0IjoxNzY4MTQzMDIyLCJleHAiOjE3Njg3NDc4MjJ9.oxmFB51Z1SEsDtLFwzxwU-jN_KlIpl7j2nE9y1Z_PKY	2026-01-11 12:08:40.01351	2026-01-11 12:08:40.01351
a4529f5b-db16-4dae-ba43-a96ee601f185	user@example.com	$2b$10$NG/i14MJd6yjA9zsUvz55uASiR4URLSjxT.pNK5MOx/55C24FOkTS	John Doe	08123456789	\N	ab42e228-882b-4f29-b9ab-1d9794decedc	f	\N	773162	2026-01-11 15:27:24.065	\N	2026-01-11 15:17:24.080459	2026-01-11 15:17:24.080459
\.


--
-- TOC entry 3314 (class 2606 OID 16396)
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- TOC entry 3316 (class 2606 OID 16398)
-- Name: categories categories_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_slug_unique UNIQUE (slug);


--
-- TOC entry 3318 (class 2606 OID 16412)
-- Name: gifts gifts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gifts
    ADD CONSTRAINT gifts_pkey PRIMARY KEY (id);


--
-- TOC entry 3320 (class 2606 OID 16418)
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 3322 (class 2606 OID 16425)
-- Name: point_balance point_balance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.point_balance
    ADD CONSTRAINT point_balance_pkey PRIMARY KEY (id);


--
-- TOC entry 3324 (class 2606 OID 16434)
-- Name: ratings ratings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ratings
    ADD CONSTRAINT ratings_pkey PRIMARY KEY (id);


--
-- TOC entry 3326 (class 2606 OID 16443)
-- Name: redemptions redemptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.redemptions
    ADD CONSTRAINT redemptions_pkey PRIMARY KEY (id);


--
-- TOC entry 3328 (class 2606 OID 16455)
-- Name: roles roles_name_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_unique UNIQUE (name);


--
-- TOC entry 3330 (class 2606 OID 16453)
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- TOC entry 3332 (class 2606 OID 16468)
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- TOC entry 3334 (class 2606 OID 16470)
-- Name: users users_google_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_google_id_unique UNIQUE (google_id);


--
-- TOC entry 3336 (class 2606 OID 16466)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3337 (class 2606 OID 16471)
-- Name: gifts gifts_category_id_categories_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gifts
    ADD CONSTRAINT gifts_category_id_categories_id_fk FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- TOC entry 3338 (class 2606 OID 16476)
-- Name: point_balance point_balance_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.point_balance
    ADD CONSTRAINT point_balance_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 3339 (class 2606 OID 16486)
-- Name: ratings ratings_gift_id_gifts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ratings
    ADD CONSTRAINT ratings_gift_id_gifts_id_fk FOREIGN KEY (gift_id) REFERENCES public.gifts(id);


--
-- TOC entry 3340 (class 2606 OID 16491)
-- Name: ratings ratings_redemption_id_redemptions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ratings
    ADD CONSTRAINT ratings_redemption_id_redemptions_id_fk FOREIGN KEY (redemption_id) REFERENCES public.redemptions(id);


--
-- TOC entry 3341 (class 2606 OID 16481)
-- Name: ratings ratings_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ratings
    ADD CONSTRAINT ratings_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 3342 (class 2606 OID 16501)
-- Name: redemptions redemptions_gift_id_gifts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.redemptions
    ADD CONSTRAINT redemptions_gift_id_gifts_id_fk FOREIGN KEY (gift_id) REFERENCES public.gifts(id);


--
-- TOC entry 3343 (class 2606 OID 16496)
-- Name: redemptions redemptions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.redemptions
    ADD CONSTRAINT redemptions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 3344 (class 2606 OID 16506)
-- Name: users users_role_id_roles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_id_roles_id_fk FOREIGN KEY (role_id) REFERENCES public.roles(id);


-- Completed on 2026-01-11 22:28:35

--
-- PostgreSQL database dump complete
--

